#!/bin/sh
java -jar JSqlBeans.jar "$1"

